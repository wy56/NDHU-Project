package com.example.tablelayout_application;

import android.app.Activity;
import android.app.AlertDialog;
import android.content.DialogInterface;
import android.os.Bundle;
import android.view.Menu;
import android.view.MenuItem;
import android.widget.Button;
import android.view.View;
import android.widget.Toast;

public class Tablelayout_Application extends Activity {
    private Button mBtnSw1, mBtnSw2, mBtnSw3, mBtnSw4;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_tablelayout__application);

        mBtnSw1 = (Button) findViewById(R.id.btnSw1);
        mBtnSw2 = (Button) findViewById(R.id.btnSw2);
        mBtnSw3 = (Button) findViewById(R.id.btnSw3);
        mBtnSw4 = (Button) findViewById(R.id.btnSw4);

        mBtnSw1.setOnClickListener(new Button.OnClickListener() {
            @Override
            public void onClick(View view){
                //when user touch btnSw1 display "1"
                //Toast.LENGTH_LONG mean display time too long, then Toast.LENGTH_SHORT mean display too short
                Toast.makeText(view.getContext(), "你按下的按鈕號碼是: 1", Toast.LENGTH_SHORT).show();
            }
        });

        mBtnSw2.setOnClickListener(new Button.OnClickListener() {
            @Override
            public void onClick(View view){
                //when user touch btnSw1 display "2"
                //Toast.LENGTH_LONG mean display time too long, then Toast.LENGTH_SHORT mean display too short
                Toast.makeText(view.getContext(), "你按下的按鈕號碼是: 2", Toast.LENGTH_SHORT).show();
            }
        });

        mBtnSw3.setOnClickListener(new Button.OnClickListener() {
            @Override
            public void onClick(View view) {
                AlertDialog.Builder dialog = new AlertDialog.Builder(Tablelayout_Application.this);
                dialog.setTitle("確認視窗");
                dialog.setMessage("你按下的按鈕號碼: 3");
                dialog.setPositiveButton("正確",
                        new DialogInterface.OnClickListener() {
                            public void onClick(
                                    DialogInterface dialoginterface, int i) {
                            }
                        });
                dialog.setNegativeButton("取消",
                        new DialogInterface.OnClickListener() {
                            public void onClick(
                                    DialogInterface dialoginterface, int i) {
                            }
                        });
                dialog.show();
            }
        });

        mBtnSw4.setOnClickListener(new Button.OnClickListener() {
            @Override
            public void onClick(View view) {
                AlertDialog.Builder dialog = new AlertDialog.Builder(Tablelayout_Application.this);
                dialog.setTitle("確認視窗");
                dialog.setMessage("你按下的按鈕號碼: 4");
                dialog.setPositiveButton("正確",
                        new DialogInterface.OnClickListener() {
                            public void onClick(
                                    DialogInterface dialoginterface, int i) {
                            }
                        });
                dialog.setNegativeButton("取消",
                        new DialogInterface.OnClickListener() {
                            public void onClick(
                                    DialogInterface dialoginterface, int i) {
                            }
                        });
                dialog.show();
            }
        });
    }
}
