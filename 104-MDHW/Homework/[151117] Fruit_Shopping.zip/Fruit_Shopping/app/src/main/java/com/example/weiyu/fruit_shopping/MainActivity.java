package com.example.weiyu.fruit_shopping;

import android.os.Bundle;
import android.support.v7.app.AppCompatActivity;
import android.support.v7.widget.Toolbar;
import android.view.View;
import android.view.Menu;
import android.view.MenuItem;
import android.app.AlertDialog;
import android.content.DialogInterface;
import android.widget.Button;
import android.widget.TextView;
import android.view.LayoutInflater;
import android.view.ViewGroup;
import android.widget.BaseAdapter;
import android.widget.CheckBox;
import android.widget.CompoundButton;
import android.widget.ImageView;
import android.widget.ListView;

public class MainActivity extends AppCompatActivity
{
    private ListView mListView;
    private TextView pay;
    private TextView ans;
    private CheckBox cb1;
    private CheckBox cb2;
    private CheckBox cb3;
    private CheckBox cb4;
    private Button go;
    String[] sel={"蘋果 ", "香蕉 ", "西瓜 " ,"木瓜"};
    int[] cost={50, 65, 300, 100};
    String s1, s2, s3, s4;
    int p1, p2, p3, p4;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);
        Toolbar toolbar = (Toolbar) findViewById(R.id.toolbar);
        setSupportActionBar(toolbar);
        cb1=(CheckBox)findViewById(R.id.cb1);
        cb2=(CheckBox)findViewById(R.id.cb2);
        cb3=(CheckBox)findViewById(R.id.cb3);
        cb4=(CheckBox)findViewById(R.id.cb4);
        cb1.setOnCheckedChangeListener(chklistener);
        cb2.setOnCheckedChangeListener(chklistener);
        cb3.setOnCheckedChangeListener(chklistener);
        cb4.setOnCheckedChangeListener(chklistener);
        ans =(TextView)findViewById(R.id.ans);
        pay=(TextView)findViewById(R.id.pay);
        mListView = (ListView) findViewById(R.id.list);
        mListView.setChoiceMode(ListView.CHOICE_MODE_SINGLE);
        mListView.setAdapter(new MyAdapter());
        go = (Button)findViewById(R.id.button);
        go.setOnClickListener(Convert);
    }

    @Override
    public boolean onCreateOptionsMenu(Menu menu) {
        // Inflate the menu; this adds items to the action bar if it is present.
        getMenuInflater().inflate(R.menu.menu_main, menu);
        return true;
    }

    @Override
    public boolean onOptionsItemSelected(MenuItem item) {
        // Handle action bar item clicks here. The action bar will
        // automatically handle clicks on the Home/Up button, so long
        // as you specify a parent activity in AndroidManifest.xml.
        switch(item.getItemId()) {
            case R.id.menu_about:
                AlertDialog.Builder bt = new AlertDialog.Builder(this);
                bt.setTitle("關於");
                bt.setMessage("製作者:陳韋佑");
                bt.setPositiveButton("確認", new DialogInterface.OnClickListener() {
                    public void onClick(DialogInterface dialog, int id) {
                    }
                });
                bt.show();
                break;
            case R.id.menu_quit:
                finish();
                break;
            default:
        }
        return super.onOptionsItemSelected(item);
    }

    private CheckBox.OnCheckedChangeListener chklistener = new CheckBox.OnCheckedChangeListener(){

        @Override
        public void onCheckedChanged(CompoundButton buttonView, boolean isChecked)
        {
            if (cb1.isChecked())
            {
                s1 = sel[0];
                p1 = cost[0];
            }
            else
            {
                s1 = "";
                p1 = 0;
            }
            if (cb2.isChecked())
            {
                s2 = sel[1];
                p2 = cost[1];
            }
            else
            {
                s2 = "";
                p2 = 0;
            }
            if (cb3.isChecked())
            {
                p3 = cost[2];
                s3 = sel[2] ;
            }
            else
            {
                s3 = "";
                p3 = 0;
            }
            if (cb4.isChecked())
            {
                p4 = cost[3];
                s4 = sel[3];
            }
            else
            {
                s4 = "";
                p4 = 0;
            }
        }
    };

    private View.OnClickListener Convert = new View.OnClickListener(){
        public void onClick(View v) {
            ans.setText("選購 : " + s1 + s2 + s3 + s4);
            pay.setText("總額 : " + Integer.toString(p1 + p2 + p3 + p4) + " 元");
        }
    };

    private class MyAdapter extends BaseAdapter{
        @Override
        public int getCount() {
            return sel.length;
        }
        @Override
        public Object getItem(int position) {
            return null;
        }

        @Override
        public long getItemId(int position) {
            setTitle(sel[position] + "每斤" + Integer.toString(cost[position]) + "元");
            return 0;
        }
        @Override
        public View getView(int position, View convertView, ViewGroup parent) {
            View v = convertView;
            Holder holder;
            if(v == null){
                v = LayoutInflater.from(getApplicationContext()).inflate(R.layout.list, null);
                holder = new Holder();
                holder.image = (ImageView) v.findViewById(R.id.image);
                holder.text = (TextView) v.findViewById(R.id.text);
                v.setTag(holder);
            }
            else{
                holder = (Holder) v.getTag();
            }
            switch(position) {
                case 0:
                    holder.image.setImageResource(R.drawable.apple);
                    holder.text.setText("蘋果");
                    break;
                case 1:
                    holder.image.setImageResource(R.drawable.banana);
                    holder.text.setText("香蕉");
                    break;
                case 2:
                    holder.image.setImageResource(R.drawable.watermelon);
                    holder.text.setText("西瓜");
                    break;
                case 3:
                    holder.image.setImageResource(R.drawable.papaya);
                    holder.text.setText("木瓜");
                    break;
            }
            return v;
        }
        class Holder{
            ImageView image;
            TextView text;
        }
    }

}
