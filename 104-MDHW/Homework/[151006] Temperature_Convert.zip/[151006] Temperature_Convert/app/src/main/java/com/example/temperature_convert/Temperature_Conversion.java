package com.example.temperature_convert;

        import android.os.Bundle;
        import android.app.Activity;
        import android.widget.Button;
        import android.widget.EditText;
        import android.widget.TextView;
        import android.view.View;


public class Temperature_Conversion extends Activity {
    private EditText mEdtTemp1;
    private Button mBtnTemp1, mBtnTemp2;
    private TextView mTxtFinish;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_temperature__conversion);

        mEdtTemp1 = (EditText) findViewById(R.id.edtTemp_1);
        mBtnTemp1 = (Button) findViewById(R.id.btnTemp_1);
        mBtnTemp2 = (Button) findViewById(R.id.btnTemp_2);
        mTxtFinish = (TextView) findViewById(R.id.textFinish);

        mBtnTemp1.setOnClickListener(Convert_temp1);
        mBtnTemp2.setOnClickListener(Convert_temp2);
    }

    private View.OnClickListener Convert_temp1 = new View.OnClickListener(){
        public void onClick(View v) {
            double f = (Double.parseDouble(mEdtTemp1.getText().toString()))*9/5+32;
            mTxtFinish.setText(getText(R.string.convert1)+Double.valueOf(f).toString());
        }
    };

    private View.OnClickListener Convert_temp2 = new View.OnClickListener(){
        public void onClick(View v) {
            double d = (Double.parseDouble(mEdtTemp1.getText().toString()))-32;
            double f = d*5/9;
            mTxtFinish.setText(getText(R.string.convert2)+Double.valueOf(f).toString());
        }
    };

}
