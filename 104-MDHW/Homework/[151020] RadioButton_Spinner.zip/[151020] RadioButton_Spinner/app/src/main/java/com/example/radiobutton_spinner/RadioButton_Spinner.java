package com.example.radiobutton_spinner;

import android.app.Activity;
import android.os.Bundle;
import android.view.View;
import android.widget.ArrayAdapter;
import android.widget.Button;
import android.widget.EditText;
import android.widget.Spinner;
import android.widget.RadioButton;
import android.widget.RadioGroup;
import android.widget.TextView;
import android.widget.AdapterView.OnItemSelectedListener;
import android.widget.AdapterView;

public class RadioButton_Spinner extends Activity {
            private EditText nameEdit;
            private Button okBtn;
            private TextView finText;
            private Spinner eduSpn;
            private RadioGroup bloodRadio;
            private RadioButton  blood_o, blood_a, blood_b, blood_ab;

            String[] Edu = new String[] {"博士", "碩士", "學士"};
            String sel_edu;

            private ArrayAdapter<String> eduList;

            @Override
            protected void onCreate(Bundle savedInstanceState) {
                super.onCreate(savedInstanceState);
                setContentView(R.layout.activity_radio_button__spinner);
                nameEdit = (EditText) findViewById(R.id.nameEdit);
                okBtn = (Button) findViewById(R.id.okBtn);
                finText = (TextView) findViewById(R.id.finText);
        eduSpn = (Spinner) findViewById(R.id.eduSpn);

        bloodRadio = (RadioGroup) findViewById(R.id.bloodRadio);
        blood_o = (RadioButton) findViewById(R.id.oRadio);
        blood_a = (RadioButton) findViewById(R.id.aRadio);
        blood_b = (RadioButton) findViewById(R.id.bRadio);
        blood_ab = (RadioButton) findViewById(R.id.abRadio);

        eduList = new ArrayAdapter<String>(this,android.R.layout.simple_spinner_item, Edu);
        eduSpn.setAdapter(eduList);
        okBtn.setOnClickListener(Fin_output);
        eduSpn.setOnItemSelectedListener(new OnItemSelectedListener() {
            @Override
            public void onItemSelected(AdapterView<?> arg0, View arg1, int position, long arg3) {
                sel_edu = Edu[position];
            }
            @Override
            public void onNothingSelected(AdapterView<?> arg0) {
                sel_edu = "沒有";
            }
        });
    }

    private View.OnClickListener Fin_output = new View.OnClickListener() {
        public void onClick(View v) {
            switch(bloodRadio.getCheckedRadioButtonId()){
                case R.id.oRadio:
                    finText.setText(nameEdit.getText() + " 的血型是 O 型，學歷是" + sel_edu);
                    break;
                case R.id.aRadio:
                    finText.setText(nameEdit.getText() + " 的血型是 A 型，學歷是" + sel_edu);
                    break;
                case R.id.bRadio:
                    finText.setText(nameEdit.getText() + " 的血型是 B 型，學歷是" + sel_edu);
                    break;
                case R.id.abRadio:
                    finText.setText(nameEdit.getText() + " 的血型是 AB 型，學歷是" + sel_edu);
                    break;
            }

        }
    };
}